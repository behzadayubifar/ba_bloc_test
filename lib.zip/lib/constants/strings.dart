const emailOrPassWordEmptyDialogTitle =
    'plaese fill in both email and the password fields';
const emailOrPassWordEmptyDialogDescription =
    'You seem to have forgotten to enter your email or password';

const loginErrorDialogTitle = 'Login Error';
const loginErrorDialogDescription =
    'There was an error logging you in. Please try again later';

const pleaseWait = 'Please wait...';

const login = 'Log in';

const enterYourPasswordHere = 'Enter your password here ...';
const enterYourEmailHere = 'Enter your email here ...';
const ok = 'OK';
const homePage = 'Home Page';
